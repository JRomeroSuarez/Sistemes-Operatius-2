Se supsa que la base de dades se situa en aquest
mateix directori.
