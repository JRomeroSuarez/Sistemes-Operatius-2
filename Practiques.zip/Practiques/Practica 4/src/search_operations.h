node_data * topWord(rb_tree * tree);//return the top word of the tree
node *recursive_search(node *n,node *best);//recursive
void search_word(char *str1,rb_tree *tree);